/*
* Name: Robert Fitch
* Date: 3/19/2025
* Edited: 4/2/2025
* Description: User object containing a user's information.
*/

#include "User.h"
#include <string>

User::User() {
	emailAddress = "";
	userPassword = "";
	firstName = "";
	lastName = "";
}

User::User(std::string emailAddress, std::string userPassword, std::string firstName, std::string lastName) {
	this->emailAddress = emailAddress;
	this->userPassword = userPassword;
	this->firstName = firstName;
	this->lastName = lastName;
}

void User::ClearUser() {
	// Set user attributes to empty strings
	this->emailAddress = "";
	this->userPassword = "";
	this->firstName = "";
	this->lastName = "";
}

bool User::IsEmpty() {
	// Check to see if email and password are empty
	if (this->emailAddress == "" && this->userPassword == "") {
		return true;
	}
	else {
		return false;
	}
}

// Accessors and Mutators
int User::GetUserId() const {
	return userId;
}
void User::SetUserId(int idToSet) {
	userId = idToSet;
}
std::string User::GetEmailAddress() const {
	return emailAddress;
}
void User::SetEmailAddress(std::string addressToSet) {
	emailAddress = addressToSet;
}
std::string User::GetPassword() const {
	return userPassword;
}
void User::SetPassword(std::string passwordToSet) {
	userPassword = passwordToSet;
}
std::string User::GetFirstName() const {
	return firstName;
}
void User::SetFirstName(std::string nameToSet) {
	firstName = nameToSet;
}
std::string User::GetLastName() const {
	return lastName;
}
void User::SetLastName(std::string nameToSet) {
	lastName = nameToSet;
}