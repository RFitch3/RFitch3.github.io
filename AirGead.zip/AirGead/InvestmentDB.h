/*
* Name: Robert Fitch
* Date: 4/2/2025
* Edited: 4/16/2025
* Description: Investment Database operations
*/

#ifndef INVESTMENT_DB_H
#define INVESTMENT_DB_H

#include <string>
#include <vector>
#include "Investment.h"
#include "User.h"

/*
* Initializes the investments table
*/
void InitInvestmentTable();

/*
* Prints the investments that a user has saved
* 
* @param currUser the user to lookup for the query
*/
void PrintInvestments(User currUser);

/*
* Saves an investment to the investments table
* 
* @param currUser the user that's saving the investment
* @param initialAmount initial investment amount to save
* @param monthlyDeposit the montly deposit to save
* @param interestRate the interest rate to save
* @param numYears the number of years to save
*/
void SaveInvestment(User currUser, double initialAmount, double monthlyDeposit, double interestRate, int numYears);

/*
* Finds an investment using the user id and investment id
* 
* @param investmentId investment ID of the investment to search for
* @param currUser the user who has the investment saved
* 
* @returns the investment if found, an empty investment if not
*/
Investment FindInvestment(int investmentId, User& currUser);

/*
* Loads a users saved investments into a vector of Investment objects
* 
* @param investments the vector to load the investments into
* @param currUser the users investments to load into the vector
*/
void LoadInvestments(std::vector<Investment>& investments, User& currUser);

/*
* Deletes an investment using the user id and investment id
*
* @param investmentId investment ID of the investment to delte for
* @param currUser the user who has the investment saved
*/
void DeleteInvestment(int investmentId, User& currUser);

#endif