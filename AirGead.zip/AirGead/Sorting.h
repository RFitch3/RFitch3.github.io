/*
* Name: Robert Fitch
* Date: 3/26/2025
* Description: Sorting functions
*/
#ifndef SORTING_H
#define SORTING_H

#include <vector>
#include "Investment.h"

/*
* This is a quicksort algorithm that can be used to sort a vector of Investment objects
* by any of the member variables.
* 
* @param investments vector of Investment objects that the algorithm will sort
* @param low lowest index in the partition
* @param high highest index in the partition
* @param comp Comparison function, should return bool denoting if elements should be swapped
*/
template <typename Compare>
void QuickSort(std::vector<Investment>& investments, int low, int high, Compare comp);

/*
* Runs the Sorting menu
* 
* @param investments the vector of investments to sort
*/
void RunSorting(std::vector<Investment>& investments);


#endif