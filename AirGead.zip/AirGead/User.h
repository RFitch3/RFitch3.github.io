/*
* Name: Robert Fitch
* Date: 3/19/2025
* Edited: 4/2/2025
* Description: User object containing a user's information.
*/
#ifndef USER_H 
#define USER_H

#include <string>

class User {
public:

	/*
	* Default constructer, sets strings to empty strings
	*/
	User();

	/*
	* Constructor using parameters to set User attributes
	*/
	User(std::string emailAddress, std::string userPassword, std::string firstName, std::string lastName);

	/*
	* Sets the user information to default (empty strings)
	*/
	void ClearUser();

	/*
	* Checks if the user object is empty
	* 
	* @returns true if the object is empty, false elsewise
	*/
	bool IsEmpty();

	/* Accessors and Mutators */
	int GetUserId() const;
	void SetUserId(int idToSet);
	std::string GetEmailAddress() const;
	void SetEmailAddress(std::string addressToSet);
	std::string GetPassword() const;
	void SetPassword(std::string passwordToSet);
	std::string GetFirstName() const;
	void SetFirstName(std::string nameToSet);
	std::string GetLastName() const;
	void SetLastName(std::string nameToSet);
private:
	int userId;
	std::string emailAddress;
	std::string userPassword;
	std::string firstName;
	std::string lastName;
};

#endif