/*
* Name: Robert Fitch
* Date: 3/26/2025
* Description: Encryption / Decryption function
*/

#include <iostream>
#include <string>

std::string EncryptDecrypt(std::string inputString, std::string key) {
	auto keyLength = key.length();
	auto inputLength = inputString.length();

	std::string outputString = inputString;

	for (int i = 0; i < inputLength; i++) {
		outputString[i] = inputString[i] ^ key[i % keyLength];
	}

	return outputString;
}