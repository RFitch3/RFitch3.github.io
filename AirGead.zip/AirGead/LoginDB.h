/*
* Name: Robert Fitch
* Date: 4/2/2025
* Description: Login Database operations
*/
#ifndef LOGIN_DB_H
#define LOGIN_DB_H

#include "User.h"
#include <string>


void PrintUsers();

/*
* If not created, creates the user table
*/
void InitUserTable();

/*
* Adds a user to the users table
* 
* @param emailAddress The email address of the user to add
* @param userPass The password of the user to add
* @param firstName The first name of the user to add
* @param lastName The last name of the user to add
*/
void AddUserToDb(std::string emailAddress, std::string userPass, std::string firstName, std::string lastName, std::string key);

/*
* Finds a User from the database
* 
* @param email The email address of the user to find
* @param password The password of the user to find
* 
* @returns A User object. This object will be empty if the User was not found.
*/
User FindUser(std::string emailAddress, std::string userPass, std::string key);

/*
* Updates a User in the users table
* 
* @param emailAddress The email address of the user to Update
* @param userPass The password to update in the users table
* @param firstName The first name to update in the users table
* @param lastName The last name to update in the users table
*/
void UpdateUserInfo(std::string emailAddress, std::string userPass, std::string firstName, std::string lastName);

/*
* Delete a user from the users table
* 
* @param emailAddress The email address of the user to delete
* @param userPass The password of the user to delete
*/
void DeleteUserFromDb(std::string emailAddress, std::string userPass);

#endif