/*
* Name: Robert Fitch
* Date: 3/21/2025
* Edited: 4/16/2025
* Description: State Machine object. Defines the state machine states and logic
*/

#include "StateMachine.h"
#include "Login.h"
#include "AirgeadBankingInput.h"
#include "AirgeadBankingDisplay.h"
#include "User.h"
#include "InvestmentDB.h"
#include "MenuControllers.h"

User currUser;
Investment currInvestment;
std::vector<Investment> investmentList;
bool limitToFive = true;

StateMachine& StateMachine::getInstance() {
	static StateMachine instance;
	return instance;
}

void StateMachine::InitilizeSM() {
	this->currState = Login;
}

// Login State
void StateMachine::LoginToHome() {
	this->currState = Home;
}

void StateMachine::LoginToExit() {
	this->currState = Exit;
}

// Menu State
void StateMachine::HomeToCreate() {
	this->currState = Create;
}

void StateMachine::HomeToLoad() {
	this->currState = Load;
}

void StateMachine::HomeToLogin() {
	// Clear the current user and investment on logout.
	currUser.ClearUser();
	currInvestment.ClearInvestment();
	this->currState = Login;
}

void StateMachine::HomeToExit() {
	this->currState = Exit;
}

// Create State
void StateMachine::CreateToInvestment() {
	this->currState = Investment;
}

// Load State
void StateMachine::LoadToCreate() {
	this->currState = Create;
}

void StateMachine::LoadToInvestment() {
	investmentList.clear();
	this->currState = Investment;
}

void StateMachine::LoadToHome() {
	this->currState = Home;
}

void StateMachine::LoadToLogin() {
	// Clear the current user, investmentList, and investment on logout.
	currUser.ClearUser();
	currInvestment.ClearInvestment();
	investmentList.clear();
	this->currState = Login;
}

void StateMachine::LoadToExit() {
	this->currState = Exit;
}

// Investment State
void StateMachine::InvestmentToLoad() {
	// Clear the current investment and investmentList
	currInvestment.ClearInvestment();
	investmentList.clear();
	this->currState = Load;
}
void StateMachine::InvestmentToLogin() {
	// Clear the current user and investment on logout.
	currUser.ClearUser();
	currInvestment.ClearInvestment();
	this->currState = Login;
}

void StateMachine::InvestmentToExit() {
	this->currState = Exit;
}

void StateMachine::UpdateSM() {
	int userChoice;
	std::string key = "weakKey";

	switch (currState) {
	case Login:
		currUser = RunLogin(key);
		// When user selects Exit, it sets the user object's email to "^exit",
		// This cannot be a user's email otherwise
		if (currUser.GetEmailAddress() == "^exit") {
			LoginToExit();
		}
		// If user isn't empty, go to main
		else if (!currUser.IsEmpty()) {
			LoginToHome();
		}
		break;
	case Home:
		userChoice = RunHomeMenu(currUser);
		if (userChoice == 1) {
			HomeToCreate();
		}
		else if (userChoice == 2) {
			HomeToLoad();
		}
		else if (userChoice == 3) {
			HomeToLogin();
		}
		else if (userChoice == 4) {
			HomeToExit();
		}
		break;
	case Create:
		GetUserInvestment(currInvestment);
		CreateToInvestment();
		break;
	case Load:
		userChoice = RunLoadMenu(currInvestment, currUser, investmentList, limitToFive);
		// Don't transition if investment is empty
		if (userChoice > 0 && currInvestment.IsEmpty()) {
			break;
		}
		else if (userChoice > 0) {
			LoadToInvestment();
		}
		else if (userChoice == -4) {
			LoadToHome();
		}
		if (userChoice == -3) {
			LoadToCreate();
		}
		else if (userChoice == -2) {
			LoadToExit();
		}
		else if (userChoice == -1) {
			LoadToLogin();
		}
		break;
	case Investment:
		userChoice = RunInvestmentMenu(currInvestment, currUser);
		if (userChoice == -1) {
			InvestmentToLoad();
		}
		else if (userChoice == -2) {
			InvestmentToLogin();
		}
		else if (userChoice == -3) {
			InvestmentToExit();
		}
		break;
	case Exit:
		break;
	default:
		break;
	}
}

void StateMachine::RunSM() {
	// Run the state machine until it enters Exit state
	while (this->currState != Exit) {
		UpdateSM();
	}
}