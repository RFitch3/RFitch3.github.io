/*
* Name: Robert Fitch
* Date: 3/28/2023
* Edited: 4/2/2025
* Description: Input functions for Airgead Banking Investment Growth program
*/

#ifndef AIRGEAD_BANKING_INPUT_H
#define AIRGEAD_BANKING_INPUT_H

#include "Investment.h"
#include "User.h"
#include <string>

/*
* Takes a string, and romoves anything that is not a digit or the first period, then converts it to a double
* 
* @param outputmessage message to output to user
* @param isFormatted pushes the output to the right for formatting
* @param formatWidth number of spaces to insert before output
* 
* @returns the double with the any other symbols removed.
*/
double GetValidDouble(std::string outputMessage, int formatWidth = 0);

/*
* Gets a valid int from the user
* 
* @param outputMessage Message to be output to the user
* 
* @returns an int that has been validated.
*/
int GetValidInt(std::string outputMessage, int formatWidth = 0);

/*
* Gets user input for investment amount monthly deposit interest rate and number of years
* 
* @param investmentAmount double variable to be updated by user input
* @param monthlyDeposit double variable to be updated by user input
* @param interestRate double variable to be updated by user input
* @param numYears int variable to be updated by user input
*/
void GetUserInvestment(Investment& currInvestment);

/*
* Gets a user choice to sort by ascending or descending
* 
* @returns true to sort by ascending, or false to sort by descending
*/
bool GetAscDesc();

#endif