/*
* Name: Robert Fitch
* Date: 4/2/2025
* Edited: 4/16/2025
* Description: Functions that run the menus
*/
#include "User.h"
#include "Investment.h"
#include "InvestmentDB.h"
#include "Login.h"
#include "LoginDB.h"
#include "AirgeadBankingDisplay.h"
#include "AirgeadBankingInput.h"
#include "Sorting.h"
#include <string>
#include <iostream>

User RunLogin(std::string key) {
	int userChoice;
	User currUser;
	std::string emailAddress;
	std::string userPassword;

	DisplayLoginMenu();
	userChoice = GetValidInt("Enter Choice: ");
	while (userChoice < 1 || userChoice > 3) {
		std::cout << "Invalid Choice. Please Enter a Number [1 - 3]." << std::endl;
		userChoice = GetValidInt("Enter Choice: ");
	}

	switch (userChoice) {
	case 1: // Login to account
		DisplayHeader(90, "Login", '*', '*');
		// Sanitize the strings to help prevent SQL injection
		emailAddress = GetSanitizedString("Enter Email: ", true, 16);
		userPassword = GetSanitizedString("Enter Password: ");
		currUser = FindUser(emailAddress, userPassword, key);
		break;
	case 2: // Create account
		DisplayHeader(90, "Create Account", '*', '*');
		CreateUser(currUser, key);
		// Get the User with the appropriate UserID
		currUser = FindUser(currUser.GetEmailAddress(), currUser.GetPassword(), key);
		break;
	case 3: // Exit
		currUser.SetEmailAddress("^exit");
		break;
	default:
		break;
	}

	return currUser;
}

int RunHomeMenu(User& currUser) {
	int userChoice;
	// Print the menu
	DisplayHomeMenu(currUser.GetFirstName());

	// Get a valid menu choice
	userChoice = GetValidInt("Enter Choice: ");
	while (userChoice < 1 || userChoice > 4) {
		std::cout << "Invalid Input. Please select a number [1 - 4]" << std::endl;
		userChoice = GetValidInt("Enter Choice: ");
	}

	return userChoice;
}

int RunLoadMenu(Investment& currInvestment, User& currUser, std::vector<Investment>& investmentList, bool& limitToFive) {
	int userChoice;

	// Only load the investments if they're not already loaded
	if (investmentList.size() == 0) {
		LoadInvestments(investmentList, currUser);
	}

	// If there are still no investments in investmentList, the user has no saved investments
	if (investmentList.size() == 0) {
		std::cout << "No Investments Saved." << std::endl;
		return -3; // Goes to create investment
	}

	DisplayLoadMenu(investmentList, limitToFive);
	userChoice = GetValidInt("Enter Choice: ");

	// For the menu if it's showing 5 investments
	if (limitToFive && investmentList.size() >= 5) {
		if (userChoice < 6) {
			currInvestment = investmentList.at(userChoice - 1);
			return investmentList.at(userChoice - 1).GetInvestmentId();
		}
		else if (userChoice == 6) {
			RunSorting(investmentList);
		}
		else if (userChoice == 7) {
			limitToFive = false; // View All
		}
		else if (userChoice == 8) {
			return -4; // Home
		}
		else if (userChoice == 9) {
			return -1; // Logout
		}
		else if (userChoice == 10) {
			return -2; // Exit
		}

	}
	// For the menu if it's showing less than five investments, or showing all investments
	else {
		if (userChoice < investmentList.size() + 1) {
			currInvestment = investmentList.at(userChoice - 1);
			return investmentList.at(userChoice - 1).GetInvestmentId();
		}
		else if (userChoice == investmentList.size() + 1) {
			RunSorting(investmentList);
		}
		else if (userChoice == investmentList.size() + 2) {
			limitToFive = true; // View Less
		}
		else if (userChoice == investmentList.size() + 3) {
			return -4; // Home
		}
		else if (userChoice == investmentList.size() + 4) {
			return -1; // Logout
		}
		else if (userChoice == investmentList.size() + 5) {
			return -2; // Exit
		}
	}
	return userChoice;
}

int RunInvestmentMenu(Investment& currInvestment, User& currUser) {
	int userChoice;
	double userAmount;

	DisplayInvestmentMenu(currInvestment);

	if (currInvestment.GetInvestmentId() == NULL) { // If the investment isn't in the DB
		// Get a valid menu choice
		userChoice = GetValidInt("Enter Choice: ");
		while (userChoice < 1 || userChoice > 9) {
			std::cout << "Invalid Input. Please select a number [1 - 9]" << std::endl;
			userChoice = GetValidInt("Enter Choice: ");
		}

		switch (userChoice) {
		case 1:
			// Ask user for new investment amount and update the Investment obj
			userAmount = GetValidDouble("Please Enter New Initial Investment Amount");
			currInvestment.SetInvestmentAmount(userAmount);
			break;
		case 2:
			// Ask user for new monthly deposit and update the Investment obj
			userAmount = GetValidDouble("Please Enter New Monthly Deposit Amount");
			currInvestment.SetMonthlyDeposit(userAmount);
			break;
		case 3:
			// Ask user for new interest amount and update the Investment obj
			userAmount = GetValidDouble("Please Enter New Annual Interest");
			currInvestment.SetInterestRate(userAmount);
			break;
		case 4:
			// Ask user for new nuber of years and update the Investment obj
			userAmount = GetValidDouble("Please Enter New Number of Years");
			currInvestment.SetNumYears(userAmount);
			break;
		case 5:
			// Print the current values of the Investment obj
			currInvestment.PrintValues();
			system("pause");
			break;
		case 6:
			// Print the year-end report
			currInvestment.PrintYearEndReport();
			system("pause");
			break;
		case 7:
			SaveInvestment(currUser, currInvestment.GetInvestmentAmount(), currInvestment.GetMonthlyDeposit(), currInvestment.GetInterestRate(), currInvestment.GetNumYears());
			return -1; // Goes to Load
			break;
		case 8:
			return -2; // Goes to Login
			break;
		case 9:
			return -3; // Goes to Exit
			break;
		default:
			break;
		}
	}
	else {
		// Get a valid menu choice
		userChoice = GetValidInt("Enter Choice: ");
		while (userChoice < 1 || userChoice > 10) {
			std::cout << "Invalid Input. Please select a number [1 - 9]" << std::endl;
			userChoice = GetValidInt("Enter Choice: ");
		}

		switch (userChoice) {
		case 1:
			// Ask user for new investment amount and update the Investment obj
			userAmount = GetValidDouble("Please Enter New Initial Investment Amount");
			currInvestment.SetInvestmentAmount(userAmount);
			break;
		case 2:
			// Ask user for new monthly deposit and update the Investment obj
			userAmount = GetValidDouble("Please Enter New Monthly Deposit Amount");
			currInvestment.SetMonthlyDeposit(userAmount);
			break;
		case 3:
			// Ask user for new interest amount and update the Investment obj
			userAmount = GetValidDouble("Please Enter New Annual Interest");
			currInvestment.SetInterestRate(userAmount);
			break;
		case 4:
			// Ask user for new nuber of years and update the Investment obj
			userAmount = GetValidDouble("Please Enter New Number of Years");
			currInvestment.SetNumYears(userAmount);
			break;
		case 5:
			// Print the current values of the Investment obj
			currInvestment.PrintValues();
			system("pause");
			break;
		case 6:
			// Print the year-end report
			currInvestment.PrintYearEndReport();
			system("pause");
			break;
		case 7:
			SaveInvestment(currUser, currInvestment.GetInvestmentAmount(), currInvestment.GetMonthlyDeposit(), currInvestment.GetInterestRate(), currInvestment.GetNumYears());
			return -1; // Goes to Load
			break;
		case 8:
			DeleteInvestment(currInvestment.GetInvestmentId(), currUser);
			currInvestment.ClearInvestment(); // Clear the current investment after it's deleted
			return -1; // Goes to Load
			break;
		case 9:
			return -2; // Goes to Login
			break;
		case 10:
			return -3; // Goes to Exit
			break;
		default:
			break;
		}
	}
	
	return userChoice;
}