/*
* Name: Robert Fitch
* Date: 3/28/2023
* Edited: 3/19/2025
* Description: Takes user input for investment amount, intrest rate, number of years and monthly deposit,
*              then displays a year-end summary report with and without a monthly deposit, for each year.
*/

#include "StateMachine.h"
#include "LoginDB.h"
#include "InvestmentDB.h"
#include <iostream>

int main() {
	// Initialize the database tables if they're not initialized yet
	InitUserTable();
	InitInvestmentTable();

	// Get the instance of the state machine and run it
	StateMachine& stateMachine = StateMachine::getInstance();
	stateMachine.RunSM();

	return 0;
}