/*
* Name: Robert Fitch
* Date: 3/21/2025
* Edited: 4/2/2025
* Description: State Machine object. Defines the state machine states and logic
*/
#ifndef STATE_MACHINE_H
#define STATE_MACHINE_H

class StateMachine {
public:
	/*
	* Get the one instance of state machine
	*/
	static StateMachine& getInstance();

	/*
	* Initialize the current state to login
	*/
	void InitilizeSM();

	/*
	* Transition from Login to Main
	*/
	void LoginToHome();
	/*
	* Transition from Login to Exit
	*/
	void LoginToExit();
	
	/*
	* Transitions from Menu to Create
	*/
	void HomeToCreate();
	/*
	* Transition from Menu to Load
	*/
	void HomeToLoad();
	/*
	* Transition from Main to Login
	* Clears user and investment objects
	*/
	void HomeToLogin();
	/*
	* Transition from Main to Exit
	*/
	void HomeToExit();

	/*
	* Transition from Create to Investment
	*/
	void CreateToInvestment();

	/*
	* Transition from Load to Create
	*/
	void LoadToCreate();
	/*
	* Transition from Load to Investment
	*/
	void LoadToInvestment();
	/*
	* Transition from Load to Menu
	*/
	void LoadToHome();
	/*
	* Transition from Load to Login
	* Clears the user and investment objects as well as the investment vector
	*/
	void LoadToLogin();
	/*
	* Transition from Load to Exit
	*/
	void LoadToExit();

	/*
	* Transition from Investment to Load
	* Clears the Investment object and Investment list on transition
	*/
	void InvestmentToLoad();
	/*
	* Transition from Investment to Login
	* Clears user and investment objects
	*/
	void InvestmentToLogin();
	/*
	* Transition from Investment to Exit
	*/
	void InvestmentToExit();

	/*
	* Defines the state transitions
	*/
	void UpdateSM();

	/*
	* Runs the state machine until it enter the Exit state
	*/
	void RunSM();
private:
	/*
	* Singleton default constructor
	*/
	StateMachine() = default;
	enum States {
		Login,
		Home,
		Create,
		Load,
		Investment,
		Exit
	};
	enum States currState;
};

#endif