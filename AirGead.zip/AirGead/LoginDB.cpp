/*
* Name: Robert Fitch
* Date: 4/2/2025
* Description: Login Database operations
*/
#include "sqlite/sqlite3.h"
#include "User.h"
#include "EncryptionDecryption.h"
#include <string>
#include <iostream>

// FIXME Delete after testing
void PrintUsers() {
	sqlite3* AirGeadDb;
	sqlite3_stmt* prepStmt;

	char* errMsg;

	sqlite3_open("AirGead.db", &AirGeadDb);

	std::string sql = "SELECT * FROM users";
	sqlite3_prepare_v2(AirGeadDb, sql.c_str(), sql.length(), &prepStmt, nullptr);
	int userId;
	const unsigned char* email;
	const unsigned char* pass;
	const unsigned char* fName;
	const unsigned char* lName;

	while (sqlite3_step(prepStmt) != SQLITE_DONE) {
		userId = sqlite3_column_int(prepStmt, 0);
		email = sqlite3_column_text(prepStmt, 1);
		pass = sqlite3_column_text(prepStmt, 2);
		fName = sqlite3_column_text(prepStmt, 3);
		lName = sqlite3_column_text(prepStmt, 4);

		std::cout << "User ID: " << userId << ", Email: " << email << ", Pass: " << pass << ", FirstName: " << fName << ", LastName: " << lName << std::endl;
	}

}

void InitUserTable() {
	sqlite3* AirGeadDb;
	char* errMsg;

	// Create the sql string
	std::string sql = "CREATE TABLE IF NOT EXISTS users("
		"user_id INTEGER PRIMARY KEY AUTOINCREMENT, "
		"email VARCHAR(30) NOT NULL UNIQUE, "
		"password VARCHAR(30) NOT NULL, "
		"first_name VARCHAR(30) NOT NULL, "
		"last_name VARCHAR(30) );";

	sqlite3_open("AirGead.db", &AirGeadDb);
	// Execute the sql statement
	int rc = sqlite3_exec(AirGeadDb, sql.c_str(), nullptr, nullptr, &errMsg);

	// If SQLite encounters a problem output the error
	if (rc != SQLITE_OK) {
		std::cout << "Error Creating users Table : " << errMsg << std::endl;
	}
	sqlite3_close(AirGeadDb);
}

void AddUserToDb(std::string emailAddress, std::string userPass, std::string firstName, std::string lastName, std::string key) {
	sqlite3* AirGeadDb;
	sqlite3_stmt* prepStmt;

	sqlite3_open("AirGead.db", &AirGeadDb);

	// Prepared statement string
	std::string sql = "INSERT INTO users (email, password, first_name, last_name) "
		"VALUES (?, ?, ?, ?);";

	int rc = sqlite3_prepare_v2(AirGeadDb, sql.c_str(), sql.length(), &prepStmt, nullptr);

	// Reject empty required fields
	if (emailAddress.size() < 1 || userPass.size() < 1 || firstName.size() < 1) {
		std::cout << "Error: Email, Password, and First Name are all required fields." << std::endl;
	}
	// If SQLite is okay, store the data in the database
	else if (rc == SQLITE_OK) {

		// Encrypt the user data
		emailAddress = EncryptDecrypt(emailAddress, key);
		userPass = EncryptDecrypt(userPass, key);
		firstName = EncryptDecrypt(firstName, key);
		lastName = EncryptDecrypt(lastName, key);

		sqlite3_bind_text(prepStmt, 1, emailAddress.c_str(), emailAddress.length(), SQLITE_STATIC);
		sqlite3_bind_text(prepStmt, 2, userPass.c_str(), userPass.length(), SQLITE_STATIC);
		sqlite3_bind_text(prepStmt, 3, firstName.c_str(), firstName.length(), SQLITE_STATIC);
		sqlite3_bind_text(prepStmt, 4, lastName.c_str(), lastName.length(), SQLITE_STATIC);

		rc = sqlite3_step(prepStmt);

		// Prompt the user if the email they entered already exists
		if (rc == SQLITE_CONSTRAINT) {
			std::cout << "Error: Email Address Already Exists" << std::endl;
		}

		// Destroy the prepared statement
		sqlite3_finalize(prepStmt);
	}

	sqlite3_close(AirGeadDb);
}

User FindUser(std::string emailAddress, std::string userPass, std::string key) {
	sqlite3* AirGeadDb;
	sqlite3_stmt* prepStmt;
	User currUser;

	sqlite3_open("AirGead.db", &AirGeadDb);

	// Prepared statement string
	std::string sql = "SELECT * FROM users WHERE email = ? AND password = ?;";

	int rc = sqlite3_prepare_v2(AirGeadDb, sql.c_str(), sql.length(), &prepStmt, nullptr);
	if (rc == SQLITE_OK) {

		// Search using encrypted strings
		emailAddress = EncryptDecrypt(emailAddress, key);
		userPass = EncryptDecrypt(userPass, key);

		sqlite3_bind_text(prepStmt, 1, emailAddress.c_str(), emailAddress.length(), SQLITE_STATIC);
		sqlite3_bind_text(prepStmt, 2, userPass.c_str(), userPass.length(), SQLITE_STATIC);
		rc = sqlite3_step(prepStmt);

		// Return an empty user object if the query was unsuccessful
		if (rc == SQLITE_DONE) {
			// Destroy the prepared statement
			sqlite3_finalize(prepStmt);
			std::cout << "User not found." << std::endl;
			return currUser;
		}		

		currUser.SetUserId(sqlite3_column_int(prepStmt, 0));
		// Convert the const unsigned char to string and assign the User variables
		currUser.SetEmailAddress(
			std::string(EncryptDecrypt(reinterpret_cast<const char*>(sqlite3_column_text(prepStmt, 1)), key)));
		currUser.SetPassword(
			std::string(EncryptDecrypt(reinterpret_cast<const char*>(sqlite3_column_text(prepStmt, 2)), key)));
		currUser.SetFirstName(
			std::string(EncryptDecrypt(reinterpret_cast<const char*>(sqlite3_column_text(prepStmt, 3)), key)));
		currUser.SetLastName(
			std::string(EncryptDecrypt(reinterpret_cast<const char*>(sqlite3_column_text(prepStmt, 4)), key)));

		// Destroy the prepared statement
		sqlite3_finalize(prepStmt);
	}
	sqlite3_close(AirGeadDb);
	return currUser;
}

void UpdateUserInfo(std::string emailAddress, std::string userPass, std::string firstName, std::string lastName) {
	sqlite3* AirGeadDb;
	sqlite3_stmt* prepStmt;

	sqlite3_open("AirGead.db", &AirGeadDb);

	// Prepared statement string
	std::string sql = "UPDATE users "
		"SET password = ?1, first_name = ?2, last_name = ?3 "
		"WHERE email = ?4;";

	int rc = sqlite3_prepare_v2(AirGeadDb, sql.c_str(), sql.length(), &prepStmt, nullptr);

	if (rc == SQLITE_OK) {
		// Bind the variables to the prepared statement
		sqlite3_bind_text(prepStmt, 1, userPass.c_str(), userPass.length(), SQLITE_STATIC);
		sqlite3_bind_text(prepStmt, 2, firstName.c_str(), firstName.length(), SQLITE_STATIC);
		sqlite3_bind_text(prepStmt, 3, lastName.c_str(), lastName.length(), SQLITE_STATIC);
		sqlite3_bind_text(prepStmt, 4, emailAddress.c_str(), emailAddress.length(), SQLITE_STATIC);

		rc = sqlite3_step(prepStmt);

		if (rc == SQLITE_DONE) {
			std::cout << "User Data successfully saved." << std::endl;
		}
		else {
			std::cout << "Error saving user data." << std::endl;
		}
		sqlite3_finalize(prepStmt);
	}
	sqlite3_close(AirGeadDb);
}



void DeleteUserFromDB(std::string emailAddress, std::string userPass) {
	sqlite3* AirGeadDb;
	sqlite3_stmt* prepStmt;

	sqlite3_open("AirGead.db", &AirGeadDb);

	// Prepared statement string
	std::string sql = "DELETE FROM users WHERE email = ? AND password = ?";

	int rc = sqlite3_prepare_v2(AirGeadDb, sql.c_str(), sql.length(), &prepStmt, nullptr);
	if (rc == SQLITE_OK) {
		// Bind the variables to the prepared statement
		sqlite3_bind_text(prepStmt, 1, emailAddress.c_str(), emailAddress.length(), SQLITE_STATIC);
		sqlite3_bind_text(prepStmt, 2, userPass.c_str(), userPass.length(), SQLITE_STATIC);
		rc = sqlite3_step(prepStmt);

		// Destroy the prepared statement
		sqlite3_finalize(prepStmt);
	}
	sqlite3_close(AirGeadDb);
}