/*
* Name: Robert Fitch
* Date: 4/2/2025
* Description: Functions that run the menus
*/
#ifndef MENU_CONTROLLERS_H
#define MENU_CONTROLLERS_H

#include "User.h"
#include "Investment.h"
#include <string>

/*
* Runs the login menu
* 
* @returns The user object that the user logged into
*/
User RunLogin(std::string key);

/*
* Runs the menu allowing various options for the user
*
* @param currUser Current user object
* 
* @returns Users menu choice
*/
int RunHomeMenu(User& currUser);

/*
* Run the load menu
* 
* @param currInvestment Investment to load
* @param currUser The user to find the investment for
* 
* @returns investment id if investment was chosen,
                      -1 if user chooses logout,
                      -2 if user chooses exit,
                      -3 if user doesn't have any investments
*/
int RunLoadMenu(Investment& currInvestment, User& currUser, std::vector<Investment>& investmentList, bool& limitToFive);

/*
* Run investment menu
* 
* @param currInvestment Investment to edit or save
* @param currUser user that's signed in
* 
* @returns user menu choice
*/
int RunInvestmentMenu(Investment& currInvestment, User& currUser);

#endif