/*
* Name: Robert Fitch
* Date: 3/28/2023
* Edited: 4/2/2025
* Description: Object containing investment information (investment amount, monthly deposit, interest rate and number of years)
*/
#ifndef INVESTMENT_H 
#define INVESTMENT_H

class Investment {
public:
	/*
	* Default constructor, sets all private variables to 0
	*/
	Investment();

	/*
	* Constructor that takes all private variables as arguements
	* 
	* @param investmentAmount Sets investment amount
	* @param monthlyDeposit Sets monthly deposit
	* @param interestRate Sets interest rate
	* @param numYears Sets number of years
	*/
	Investment(double investmentAmount, double monthlyDeposit, double interestRate, int numYears);
	
	/*
	* Calculates the year-end interest and year-end investment, for 1 year
	* Sets the private doubles yearEndInterest and yearEndInvestment
	*/
	void CalculateYearEndTotals(bool deposit = true);

	/*
	* Sets yearEndInterest and yearEndInvestment to 0.0
	*/
	void ClearYearEndTotals();

	/*
	* Sets all of the investments variables to default
	*/
	void ClearInvestment();

	/*
	* Loops numYears times printing a year-end report with and without a monthly deposit
	*/
	void PrintYearEndReport();

	/*
	* Prints the current values of Investment
	*/
	void PrintValues();

	/*
	* Checks if an investment is empty
	* 
	* @return true if the investment is empty, false if the investment has data
	*/
	bool IsEmpty();

	/*
	* Returns the investment id
	* 
	* @returns the investment id of the Investment
	*/
	int GetInvestmentId() const;
	/*
	* Sets the Investment's id field
	* 
	* @param idToSet the id to set
	*/
	void SetInvestmentId(int idToSet);
	/*
	* Returns the investmentAmount double
	*/
	double GetInvestmentAmount() const;
	/*
	* Assigns amount to set to investmentAmount
	* 
	* @param amountToSet double value to assign to investmentAmount
	*/
	void SetInvestmentAmount(double amountToSet);
	/*
	* Returns the monthlyDeposit double
	*/
	double GetMonthlyDeposit() const;
	/*
	* Assigns amount to set to monthlyDeposit
	*
	* @param amountToSet double value to assign to monthlyDeposit
	*/
	void SetMonthlyDeposit(double amountToSet);
	/*
	* Returns the interestRate double
	*/
	double GetInterestRate() const;
	/*
	* Assigns rateToSet to interestRate
	*
	* @param rateToSet double value to assign to interestRate
	*/
	void SetInterestRate(double rateToSet);
	/*
	* returns numYears int
	*/
	int GetNumYears() const;
	/*
	* Assigns yearsToSet to numYears
	*
	* @param yearsToSet int value to assign to numYears
	*/
	void SetNumYears(int yearsToSet);
	/*
	* Returns the yearEndInterest double
	*/
	double GetYearEndInterest();
	/*
	* Returns the yearEndInvestment double
	*/
	double GetYearEndInvestment();

private:
	int investmentId;
	double investmentAmount;
	double monthlyDeposit;
	double interestRate;
	int numYears;
	double yearEndInterest;
	double yearEndInvestment;
};


#endif
