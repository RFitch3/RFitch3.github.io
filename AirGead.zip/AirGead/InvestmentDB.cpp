/*
* Name: Robert Fitch
* Date: 4/2/2025
* Edited: 4/16/2025
* Description: Investment Database operations
*/

#include "sqlite/sqlite3.h"
#include "User.h"
#include "EncryptionDecryption.h"
#include "Investment.h"
#include <string>
#include <iostream>
#include <vector>

void InitInvestmentTable() {
	sqlite3* AirGeadDb;
	char* errMsg;

	// Create the sql string
	std::string sql = "CREATE TABLE IF NOT EXISTS investments("
		"investment_id INTEGER PRIMARY KEY AUTOINCREMENT, "
		"user_id INTEGER, "
		"initial_investment DOUBLE(10, 2), "
		"monthly_deposit DOUBLE(10, 2), "
		"interest_rate DOUBLE(3, 2), "
		"num_years INT, "
		"FOREIGN KEY(user_id) REFERENCES users(user_id) );";

	sqlite3_open("AirGead.db", &AirGeadDb);
	// Execute the sql statement
	int rc = sqlite3_exec(AirGeadDb, sql.c_str(), nullptr, nullptr, &errMsg);

	// If SQLite encounters a problem output the error
	if (rc != SQLITE_OK) {
		std::cout << "Error Creating investments Table : " << errMsg << std::endl;
	}
	sqlite3_close(AirGeadDb);
}

void PrintInvestments(User currUser) {
	sqlite3* AirGeadDb;
	sqlite3_stmt* prepStmt;

	sqlite3_open("AirGead.db", &AirGeadDb);

	// SQL statement to execute
	std::string sql =
		"SELECT * FROM investments "
		"WHERE user_id = ?;";

	int rc = sqlite3_prepare_v2(AirGeadDb, sql.c_str(), sql.length(), &prepStmt, nullptr);
	
	if (rc == SQLITE_OK) {
		// Bind the user ID to the prepared statement
		sqlite3_bind_int(prepStmt, 1, currUser.GetUserId());
		double initialAmount;
		double monthlyDeposit;
		double interestRate;
		int numYears;
		bool isEmpty = true;

		std::cout << std::endl;
		// Loop through the investments and assign the columns to the correct variables
		while (sqlite3_step(prepStmt) != SQLITE_DONE) {
			initialAmount = sqlite3_column_double(prepStmt, 2);
			monthlyDeposit = sqlite3_column_double(prepStmt, 3);
			interestRate = sqlite3_column_double(prepStmt, 4);
			numYears = sqlite3_column_int(prepStmt, 5);

			std::cout << "Initial Amount: " << initialAmount
				<< ", Monthly Deposit: " << monthlyDeposit
				<< ", Interest Rate: " << interestRate
				<< ", Number of Years: " << numYears << std::endl;
			// Set isEmpty to false to show that investments were found
			isEmpty = false;
		}
		if (isEmpty) {
			std::cout << "No investments saved." << std::endl;
		}
		std::cout << std::endl;
		sqlite3_finalize(prepStmt);
	}
	sqlite3_close(AirGeadDb);
}

void SaveInvestment(User currUser, double initialAmount, double monthlyDeposit, double interestRate, int numYears) {
	sqlite3* AirGeadDb;
	sqlite3_stmt* prepStmt;

	sqlite3_open("AirGead.db", &AirGeadDb);

	// Prepared statement string
	std::string sql =
		"INSERT INTO investments (user_id, initial_investment, monthly_deposit, interest_rate, num_years) "
		"VALUES (?, ?, ?, ?, ?);";

	int rc = sqlite3_prepare_v2(AirGeadDb, sql.c_str(), sql.length(), &prepStmt, nullptr);

	if (rc == SQLITE_OK) {
		// Bind the variables to the prepared statement
		sqlite3_bind_int(prepStmt, 1, currUser.GetUserId());
		sqlite3_bind_double(prepStmt, 2, initialAmount);
		sqlite3_bind_double(prepStmt, 3, monthlyDeposit);
		sqlite3_bind_double(prepStmt, 4, interestRate);
		sqlite3_bind_int(prepStmt, 5, numYears);

		// Run the sql statement
		rc = sqlite3_step(prepStmt);

		// If there's an error, output it to the console
		if (rc != SQLITE_DONE) {
			std::cout << "Error Saving Investment." << std::endl;
		}

		sqlite3_finalize(prepStmt);
	}
	sqlite3_close(AirGeadDb);
}

Investment FindInvestment(int investmentId, User& currUser) {
	sqlite3* AirGeadDb;
	sqlite3_stmt* prepStmt;

	Investment currInvestment;

	sqlite3_open("AirGead.db", &AirGeadDb);

	// SQL statement to execute
	std::string sql =
		"SELECT * FROM investments "
		"WHERE user_id = ? "
		"AND investment_id = ?;";

	int rc = sqlite3_prepare_v2(AirGeadDb, sql.c_str(), sql.length(), &prepStmt, nullptr);

	if (rc == SQLITE_OK) {
		// Bind the variables to the prepared statement
		sqlite3_bind_int(prepStmt, 1, currUser.GetUserId());
		sqlite3_bind_int(prepStmt, 2, investmentId);
		rc = sqlite3_step(prepStmt);
		if (rc == SQLITE_DONE) {
			currInvestment.SetInvestmentId(sqlite3_column_int(prepStmt, 0));
			currInvestment.SetInvestmentAmount(sqlite3_column_double(prepStmt, 2));
			currInvestment.SetMonthlyDeposit(sqlite3_column_double(prepStmt, 3));
			currInvestment.SetInterestRate(sqlite3_column_double(prepStmt, 4));
			currInvestment.SetNumYears(sqlite3_column_int(prepStmt, 5));
		}
		else {
			std::cout << "Error: Investment not found." << std::endl;
		}
		sqlite3_finalize(prepStmt);
	}
	sqlite3_close(AirGeadDb);
	return currInvestment;
}

void LoadInvestments(std::vector<Investment>& investments, User& currUser) {
	sqlite3* AirGeadDb;
	sqlite3_stmt* prepStmt;

	Investment currInvestment;

	sqlite3_open("AirGead.db", &AirGeadDb);

	// SQL statement to execute
	std::string sql =
		"SELECT * FROM investments "
		"WHERE user_id = ? "
		"ORDER BY investment_id DESC;";

	int rc = sqlite3_prepare_v2(AirGeadDb, sql.c_str(), sql.length(), &prepStmt, nullptr);

	if (rc == SQLITE_OK) {
		// Bind user ID to the prepared statement
		sqlite3_bind_int(prepStmt, 1, currUser.GetUserId());

		while (sqlite3_step(prepStmt) != SQLITE_DONE) {
			// Step through returned results and add currInvestment to investments for each one
			currInvestment.SetInvestmentId(sqlite3_column_int(prepStmt, 0));
			currInvestment.SetInvestmentAmount(sqlite3_column_double(prepStmt, 2));
			currInvestment.SetMonthlyDeposit(sqlite3_column_double(prepStmt, 3));
			currInvestment.SetInterestRate(sqlite3_column_double(prepStmt, 4));
			currInvestment.SetNumYears(sqlite3_column_int(prepStmt, 5));
			investments.push_back(currInvestment);
		}
		sqlite3_finalize(prepStmt);
	}
	sqlite3_close(AirGeadDb);
}

void DeleteInvestment(int investmentId, User& currUser) {
	sqlite3* AirGeadDb;
	sqlite3_stmt* prepStatement;

	sqlite3_open("AirGead.db", &AirGeadDb);

	// SQL statement
	std::string sql =
		"DELETE FROM investments "
		"WHERE user_id = ? "
		"AND investment_id = ?;";

	int rc = sqlite3_prepare_v2(AirGeadDb, sql.c_str(), sql.length(), &prepStatement, nullptr);

	if (rc == SQLITE_OK) {
		// Bind prepared statement
		sqlite3_bind_int(prepStatement, 1, currUser.GetUserId());
		sqlite3_bind_int(prepStatement, 2, investmentId);

		rc = sqlite3_step(prepStatement);

		if (rc == SQLITE_DONE) {
			std::cout << "Investment Removed!" << std::endl;
		}
		else {
			std::cout << "Error: " << rc << " please try again." << std::endl;
		}

		sqlite3_finalize(prepStatement);
	}
	sqlite3_close(AirGeadDb);
}