/*
* Name: Robert Fitch
* Date: 3/19/2025
* Description: Displays and runs the login screen
*/

#include "Login.h"
#include "LoginDB.h"
#include <string>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include "AirgeadBankingDisplay.h"
#include "AirgeadBankingInput.h"
#include "EncryptionDecryption.h"



User CreateUser(std::string key) {
	std::string emailAddress;
	std::string userPassword;
	std::string firstName;
	std::string lastName;

	// Get user input
	emailAddress = GetSanitizedString("Enter Email Address: ", true, 23);
	userPassword = GetSanitizedString("Enter Password: ", false, 23);
	firstName = GetSanitizedString("Enter Your First Name: ", false, 23);
	lastName = GetSanitizedString("Enter Your Last Name: ", false, 23);

	// Create the user object
	User currUser(emailAddress, userPassword, firstName, lastName);

	// Write the user's data to LoginData.txt
	AddUserToDb(currUser.GetEmailAddress(),
		currUser.GetPassword(),
		currUser.GetFirstName(),
		currUser.GetLastName(), key);

	std::ofstream loginFile("LoginData.txt", std::ofstream::app);
	if (loginFile.is_open()) {
		loginFile << currUser.GetEmailAddress() << "," << currUser.GetPassword() << "," << currUser.GetFirstName() << "," << currUser.GetLastName() << std::endl;
		loginFile.close();
	}
	else {
		throw std::fstream::failure("Failed to open file. (Login line 28).\n");
	}

	return currUser;
}

void CreateUser(User& currUser, std::string key){
	std::string emailAddress;
	std::string userPassword;
	std::string firstName;
	std::string lastName;
	std::string csvString;

	// Get user input
	std::cout << std::endl;
	emailAddress = GetSanitizedString("Enter Email Address: ", true, 23);
	std::cout << std::endl;
	userPassword = GetSanitizedString("Enter Password : ", false, 23);
	std::cout << std::endl;
	firstName = GetSanitizedString("Enter Your First Name: ", false, 23);
	std::cout << std::endl;
	lastName = GetSanitizedString(" Enter Your Last Name: ", false, 23);
	std::cout << std::endl;

	// Set the User variables
	currUser.SetEmailAddress(emailAddress);
	currUser.SetPassword(userPassword);
	currUser.SetFirstName(firstName);
	currUser.SetLastName(lastName);

	AddUserToDb(currUser.GetEmailAddress(),
		currUser.GetPassword(),
		currUser.GetFirstName(),
		currUser.GetLastName(), key);

	// Write the new user to LoginData.txt
	std::ofstream loginFile("LoginData.txt", std::ofstream::app);
	if (loginFile.is_open()) {
		csvString = currUser.GetEmailAddress() + "," +
			currUser.GetPassword() + "," +
			currUser.GetFirstName() + "," +
			currUser.GetLastName();
		loginFile << EncryptDecrypt(csvString, key) << "\n";
		loginFile.close();
	}
	else {
		throw std::fstream::failure("Failed to open file. (Login line 64).\n");
	}
}

bool SanitizedString(std::string stringToCheck, bool isEmail) {
	std::string validChars;

	// Allow '@' and '.' if the string is for an email address
	// TODO Change this to allow more password options
	if (isEmail) {
		validChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ01234567890_@.";
	}
	else {
		validChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ01234567890_";
	}
	// Checks stringToCheck for characters not in validChars
	if (stringToCheck.find_first_not_of(validChars) != std::string::npos) {
		return false;
	}
	else {
		return true;
	}
}

std::string GetSanitizedString(std::string outputMessage, bool isEmail, int formatWidth) {
	std::string userInput;

	std::cout << std::endl << std::setw(formatWidth) << outputMessage;
	std::cin >> userInput;

	// Loop until user enters a sanitized string
	while (!SanitizedString(userInput, isEmail)) {
		std::cout << "\nPlease remove special characters and try again." << std::endl;
		// Clear the cin function
		std::cin.clear();
		while (std::cin.get() != '\n');
		// Get new input
		std::cout << std::endl << std::setw(formatWidth) << outputMessage;
		std::cin >> userInput;
	}
	return userInput;
}