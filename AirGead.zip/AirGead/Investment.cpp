/*
* Name: Robert Fitch
* Date: 3/28/2023
* Edited: 4/2/2025
* Description: Object containing investment information (investment amount, monthly deposit, interest rate and number of years)
*/
#include "Investment.h"
#include "AirgeadBankingDisplay.h"
#include <iostream>
#include <iomanip>
#include <cmath>

Investment::Investment() {
	// Initialize all values to 0
	investmentAmount = 0.0;
	monthlyDeposit = 0.0;
	interestRate = 0.0;
	numYears = 0;
	yearEndInterest = 0.0;
	yearEndInvestment = 0.0;
}

Investment::Investment(double investmentAmount, double monthlyDeposit, double interestRate, int numYears) {
	// Initilize all values to param values
	this->investmentAmount = investmentAmount;
	this->monthlyDeposit = monthlyDeposit;
	this->interestRate = interestRate;
	this->numYears = numYears;
	// Initialize year-end totals to 0
	yearEndInterest = 0.0;
	yearEndInvestment = 0.0;
}

void Investment::CalculateYearEndTotals(bool deposit) {
	const int NUM_MONTHS = 12;
	double monthlyInterest;
	double currMonthlyDeposit;

	// Reset the yearEndInterest
	yearEndInterest = 0.0;

	// If calculating without monthly deposits, set currMonthlyDeposit to 0
	if (!deposit) {
		currMonthlyDeposit = 0.0;
	}
	// If calculating with monthly deposit, set currMonthlyDeposit to monthlyDeposit
	else {
		currMonthlyDeposit = monthlyDeposit;
	}
	// Check to see if yearEndInvestment has been updated, and sets it to investmentAmount if not
	// This allows the program to track multiple years
	if (fabs(yearEndInvestment) < 0.0001) {
		yearEndInvestment = investmentAmount;
	}
	
	// Loops through 12 months of compounding interest
	for (int i = 0; i < NUM_MONTHS; ++i) {
		// Calculate the monthly interest
		monthlyInterest = (yearEndInvestment + currMonthlyDeposit) * ((interestRate / 100.0) / 12.0);
		// Add the monthly interest to the year-end interest
		yearEndInterest += monthlyInterest;
		// Add the deposit and the interest to the year-end investment
		yearEndInvestment += currMonthlyDeposit + monthlyInterest;
	}
	// Round to the nearest hundreth
	yearEndInterest = (floor(yearEndInterest * 100 + 0.5) / 100);
	yearEndInvestment = (floor(yearEndInvestment * 100 + 0.5) / 100);
}

void Investment::ClearYearEndTotals() {
	// Sets yearEndInterest and yearEndInvestment to 0
	yearEndInterest = 0.0;
	yearEndInvestment = 0.0;
}

void Investment::ClearInvestment() {
	// Sets investment attributes to 0
	investmentId = NULL;
	investmentAmount = 0.0;
	monthlyDeposit = 0.0;
	interestRate = 0.0;
	numYears = 0;
	yearEndInterest = 0.0;
	yearEndInvestment = 0.0;
}

void Investment::PrintYearEndReport() {
	// Print headers
	DisplayHeader(90, "Balance and Interest Without Additional Monthly Deposits");
	DisplayYearEndHeader();

	// Loop numYears times
	for (int i = 1; i <= numYears; ++i) {
		// First report without monthly deposits
		CalculateYearEndTotals(false);
		DisplayYearEndValues(i, yearEndInvestment, yearEndInterest);
	}

	// Clear the totals for the next report
	ClearYearEndTotals();

	// Headers for the 2nd report
	DisplayHeader(90, "Balance and Interest With Additional Monthly Deposits");
	DisplayYearEndHeader();

	// Loop numYears times
	for (int i = 1; i <= numYears; ++i) {
		// Second report with monthly deposits
		CalculateYearEndTotals();
		DisplayYearEndValues(i, yearEndInvestment, yearEndInterest);
	}

	// Clear the totals for the next report
	ClearYearEndTotals();

	// Print a bottom boarder
	std::cout << BoarderString(90, '-') << std::endl;
}

void Investment::PrintValues() {
	// Prints the current values of the investment
	DisplayHeader(90, "Current Investment Values");
	std::cout << "Initial Investment Amount: $" << investmentAmount << std::endl;
	std::cout << std::endl << std::setw(28) << "Monthly Deposit: $" << monthlyDeposit << std::endl;
	std::cout << std::endl << std::setw(28) << "Annual Interest:  " << interestRate << '%' << std::endl;
	std::cout << std::endl << std::setw(28) << "Number of years:  " << numYears << std::endl;
}

bool Investment::IsEmpty() {
	if (investmentAmount < 0.001 && monthlyDeposit < 0.001 && interestRate < 0.001 && numYears == 0) {
		return true;
	}
	else {
		return false;
	}
}

// Accessors and mutators
int Investment::GetInvestmentId() const {
	return investmentId;
}
void Investment::SetInvestmentId(int idToSet) {
	investmentId = idToSet;
}
double Investment::GetInvestmentAmount() const {
	return investmentAmount;
}
void Investment::SetInvestmentAmount(double amountToSet) {
	investmentAmount = amountToSet;
}
double Investment::GetMonthlyDeposit() const {
	return monthlyDeposit;
}
void Investment::SetMonthlyDeposit(double amountToSet) {
	monthlyDeposit = amountToSet;
}
double Investment::GetInterestRate() const {
	return interestRate;
}
void Investment::SetInterestRate(double rateToSet) {
	interestRate = rateToSet;
}
int Investment::GetNumYears() const {
	return numYears;
}
void Investment::SetNumYears(int yearsToSet) {
	numYears = yearsToSet;
}
double Investment::GetYearEndInterest() {
	return yearEndInterest;
}
double Investment::GetYearEndInvestment() {
	return yearEndInvestment;
}