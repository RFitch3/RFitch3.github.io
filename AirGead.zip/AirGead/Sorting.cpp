/*
* Name: Robert Fitch
* Date: 3/26/2025
* Description: Sorting functions
*/
#include "Investment.h"
#include "AirgeadBankingDisplay.h"
#include "AirgeadBankingInput.h"
#include <vector>
#include <utility>
#include <ctime>
#include <cstdlib>
#include <iostream>

template <typename Compare>
void QuickSort(std::vector<Investment>& investments, int low, int high, Compare comp) {
	
	if (low < high) {
		// Get a random pivot index and the pivot value associated with that index
		srand(time(0));
		int randPivotIndex = low + rand() % (high - low + 1);
		Investment pivotValue = investments[randPivotIndex];

		// Place the pivot value at the end of the vector
		std::swap(investments[randPivotIndex], investments[high]);
		
		// i starts 1 before the beginning of the partition
		int i = low - 1;

		for (int j = low; j < high; j++) {
			// If the comparison returns true, inc i, and swap the elements at i and j.
			if (comp(investments[j], pivotValue)) {
				i++;
				std::swap(investments[i], investments[j]);
			}
		}

		// Swap the pivot element to the correct position
		std::swap(investments[i + 1], investments[high]);

		// Recursively call QuickSort on the low and high partitions
		QuickSort(investments, low, i, comp);
		QuickSort(investments, (i + 2), high, comp); // i + 2 skips the pivot element
	}
}

void RunSorting(std::vector<Investment>& investments) {
	int n = investments.size() - 1;
	int userChoice;
	bool ascending;

	DisplaySortingMenu();
	userChoice = GetValidInt("Enter Choice: ");
	while (userChoice < 1 || userChoice > 5) {
		std::cout << "Invalid Input. Please select a number [1 - 5]" << std::endl;
		userChoice = GetValidInt("Enter Choice: ");
	}
	if (userChoice != 5) {
		ascending = GetAscDesc();
	}


	switch (userChoice) {
	case 1:
		// Use < in the lambda to ASC sort, > for DESC
		if (ascending) {
			std::cout << "Sorting by Ascending Investment Amount..." << std::endl;
			QuickSort(investments, 0, n, [](Investment firstInvestment, Investment secondInvestment) {
				return firstInvestment.GetInvestmentAmount() < secondInvestment.GetInvestmentAmount();
				});
		}
		else {
			std::cout << "Sorting by Descending Investment Amount..." << std::endl;
			QuickSort(investments, 0, n, [](Investment firstInvestment, Investment secondInvestment) {
				return firstInvestment.GetInvestmentAmount() > secondInvestment.GetInvestmentAmount();
				});
		}
		break;
	case 2:
		if (ascending) {
			std::cout << "Sorting by Ascending Montly Deposit..." << std::endl;
			QuickSort(investments, 0, n, [](Investment firstInvestment, Investment secondInvestment) {
				return firstInvestment.GetMonthlyDeposit() < secondInvestment.GetMonthlyDeposit();
				});
		}
		else {
			std::cout << "Sorting by Descending Monthly Deposit..." << std::endl;
			QuickSort(investments, 0, n, [](Investment firstInvestment, Investment secondInvestment) {
				return firstInvestment.GetMonthlyDeposit() > secondInvestment.GetMonthlyDeposit();
				});
		}
		break;
	case 3:
		if (ascending) {
			std::cout << "Sorting by Ascending Interest Rate..." << std::endl;
			QuickSort(investments, 0, n, [](Investment firstInvestment, Investment secondInvestment) {
				return firstInvestment.GetInterestRate() < secondInvestment.GetInterestRate();
				});
		}
		else {
			std::cout << "Sorting by Descending Interest Rate..." << std::endl;
			QuickSort(investments, 0, n, [](Investment firstInvestment, Investment secondInvestment) {
				return firstInvestment.GetInterestRate() > secondInvestment.GetInterestRate();
				});
		}
		break;
	case 4:
		if (ascending) {
			std::cout << "Sorting by Ascending Number of Years..." << std::endl;
			QuickSort(investments, 0, n, [](Investment firstInvestment, Investment secondInvestment) {
				return firstInvestment.GetNumYears() < secondInvestment.GetNumYears();
				});
		}
		else {
			std::cout << "Sorting by Descending Number of Years..." << std::endl;
			QuickSort(investments, 0, n, [](Investment firstInvestment, Investment secondInvestment) {
				return firstInvestment.GetNumYears() > secondInvestment.GetNumYears();
				});
		}
		break;
	case 5:
		break;
	default:
		break;
	}
}