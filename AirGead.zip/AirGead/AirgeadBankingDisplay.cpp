/*
* Name: Robert Fitch
* Date: 3/28/2023
* Edited: 4/16/2025
* Description: Display functions for Airgead Banking Investment Growth program
*/

#include "AirgeadBankingDisplay.h"
#include "Investment.h"
#include "EncryptionDecryption.h"
#include "AirgeadBankingInput.h"
#include <string>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <vector>

std::string BoarderString(unsigned int boarderLength, char boarderChar) {
	std::string newBoarderString(boarderLength, boarderChar);
	return newBoarderString;
}

std::string CenterString(unsigned int width, std::string stringToCenter, bool shift) {
	int numBlankSpaces = width - stringToCenter.size();
	std::string centeredString = "";

	// Return an error if string length is greater than width
	if (numBlankSpaces < 0) {
		throw std::invalid_argument("String length greater than width (AirgeadBankingDisplay line 21).");
	}

	// If the output needs an even amount of blank spaces, put an even amount on each side of the string
	if ((numBlankSpaces % 2) == 0) {
		centeredString += BoarderString((numBlankSpaces / 2), ' ') + stringToCenter + BoarderString((numBlankSpaces / 2), ' ');
	}
	// If the output needs an odd amount of spaces, and shift is true, print string with an extra space on the right
	else if (shift){
		centeredString += BoarderString((numBlankSpaces / 2), ' ') + stringToCenter + BoarderString((numBlankSpaces / 2) + 1, ' ');
	}
	// If the output needs an odd amount of spaces, and shift is false, print string with an extra space on the left
	else {
		centeredString += BoarderString((numBlankSpaces / 2) + 1, ' ') + stringToCenter + BoarderString((numBlankSpaces / 2), ' ');
	}
	return centeredString;
}

void DisplayHeader(unsigned int width, std::string displayMessage, char topBottomBoarderChar, char sideBoarderChar) {
	std::string boarder = BoarderString(width, topBottomBoarderChar);

	// Print the header
	try {
		std::cout << boarder << std::endl;
		std::cout << sideBoarderChar << BoarderString(width - 2, ' ') << sideBoarderChar << std::endl;
		std::cout << sideBoarderChar << CenterString(width - 2, displayMessage) << sideBoarderChar << std::endl;
		std::cout << sideBoarderChar << BoarderString(width - 2, ' ') << sideBoarderChar << std::endl;
		std::cout << boarder << std::endl;
	}
	// Catches errer in CenterString()
	catch (std::invalid_argument& e) {
		std::cerr << "Error: " << e.what() << std::endl;
	}
}


void DisplayYearEndHeader() {
	// Prints the formatted year end header
	try {
		std::cout << '|' << CenterString(28, "Year") << '|';
		std::cout << CenterString(29, "Year-End Balance") << '|';
		std::cout << CenterString(29, "Year-End Earned Interest") << '|' << std::endl;
		std::cout << BoarderString(90, '-') << std::endl;
	}
	// Catches errer in CenterString()
	catch (std::invalid_argument& e) {
		std::cerr << "Error: " << e.what() << std::endl;
	}
}



void DisplayYearEndValues(int year, double yearEndBalance, double yearEndInterest) {
	// Convert the int and doubles to strings
	std::string yearString = std::to_string(year);
	std::string balanceString = std::to_string(yearEndBalance);
	std::string interestString = std::to_string(yearEndInterest);

	try {
		// Put a '$' before the string, and take off additional digits
		balanceString = '$' + balanceString.substr(0, balanceString.find('.') + 3);
		interestString = '$' + interestString.substr(0, interestString.find('.') + 3);

		// Print the formatted values
		std::cout << '|' << CenterString(28, yearString) << '|' << CenterString(29, balanceString) << '|' << CenterString(29, interestString, false) << '|' << std::endl;
	}
	// Catches errer in CenterString()
	catch (std::invalid_argument& e) {
		std::cerr << "Error: " << e.what() << std::endl;
	}
}

void DisplayHomeMenu(std::string userName) {
	// Prints menu options
	std::cout << std::endl;
	DisplayHeader(90, "Welcome " + userName, '*', '*');
	std::cout << "   1: New Investment" << std::endl;
	std::cout << "   2: Load Investment" << std::endl;
	std::cout << "   3: Logout" << std::endl;
	std::cout << "   4: Exit" << std::endl;
}

void DisplayLoginMenu() {
	// Prints login options
	DisplayHeader(90, "Air Gead Banking Login", '*', '*');
	std::cout << "   1: Login to Account" << std::endl;
	std::cout << "   2: Create Account" << std::endl;
	std::cout << "   3: Exit" << std::endl;
}

void DisplaySortingMenu() {
	DisplayHeader(90, "Sort Investments", '*', '*');
	std::cout << "   1: Sort by Investment Amount" << std::endl;
	std::cout << "   2: Sort by Monthly Deposit" << std::endl;
	std::cout << "   3: Sort by Interest Rate" << std::endl;
	std::cout << "   4: Sort by Number of Years" << std::endl;
	std::cout << "   5: Exit" << std::endl;
}

std::string DisplaySingleInvestment(Investment userInvestment) {
	std::stringstream sStream;
	sStream << "Initial Amount: " << userInvestment.GetInvestmentAmount()
		<< ", Monthly Deposit: " << userInvestment.GetMonthlyDeposit()
		<< ", Interest Rate: " << userInvestment.GetInterestRate()
		<< ", Number of Years: " << userInvestment.GetNumYears();
	return sStream.str();
}

void DisplayLoadMenu(std::vector<Investment> investmentList, bool limitToFive) {
	int userChoice;

	std::cout << std::endl;
	DisplayHeader(90, "Load Investment", '*', '*');

	// If the list is too small to print 5, use the list size
	if (limitToFive && investmentList.size() >= 5) {
		for (int i = 0; i < 5; i++) {
			std::cout << "   " << i + 1 << ": " << DisplaySingleInvestment(investmentList.at(i)) << std::endl;
		}
		std::cout << "   6: Sort List" << std::endl;
		std::cout << "   7: View All" << std::endl;
		std::cout << "   8: Home" << std::endl;
		std::cout << "   9: Logout" << std::endl;
		std::cout << "  10: Exit" << std::endl;
	}
	// Displays the entire list of investments in investmentList
	else {
		for (int i = 0; i < investmentList.size(); i++) {
			std::cout << "   " << i + 1 << ": " << DisplaySingleInvestment(investmentList.at(i)) << std::endl;
		}
		std::cout << "   " << investmentList.size() + 1 << ": Sort List" << std::endl;
		std::cout << "   " << investmentList.size() + 2 << ": View Less" << std::endl;
		std::cout << "   " << investmentList.size() + 3 << ": Home" << std::endl;
		std::cout << "   " << investmentList.size() + 4 << ": Logout" << std::endl;
		std::cout << "   " << investmentList.size() + 5 << ": Exit" << std::endl;
	}
	
}

void DisplayInvestmentMenu(Investment &currInvestment) { 
		
	if (currInvestment.GetInvestmentId() == NULL) { // Don't display the delete option for a new investment
		DisplayHeader(90, "Investment", '*', '*');
		std::cout << "   1: Edit Initial Investment" << std::endl;
		std::cout << "   2: Edit Monthly Deposit" << std::endl;
		std::cout << "   3: Edit Annual Interest" << std::endl;
		std::cout << "   4: Edit Number of Years" << std::endl;
		std::cout << "   5: View Investment" << std::endl;
		std::cout << "   6: Run Year-End Report" << std::endl;
		std::cout << "   7: Save Investment" << std::endl;
		std::cout << "   8: Logout" << std::endl;
		std::cout << "   9: Exit" << std::endl;
	}
	else {
		DisplayHeader(90, "Investment", '*', '*');
		std::cout << "   1: Edit Initial Investment" << std::endl;
		std::cout << "   2: Edit Monthly Deposit" << std::endl;
		std::cout << "   3: Edit Annual Interest" << std::endl;
		std::cout << "   4: Edit Number of Years" << std::endl;
		std::cout << "   5: View Investment" << std::endl;
		std::cout << "   6: Run Year-End Report" << std::endl;
		std::cout << "   7: Save Investment" << std::endl;
		std::cout << "   8: Delete Investment" << std::endl;
		std::cout << "   9: Logout" << std::endl;
		std::cout << "  10: Exit" << std::endl;
	}
}

/*
* Args = ids
* if (investment found)
*	display menu w/ delete option
*/