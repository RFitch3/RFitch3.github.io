/*
* Name: Robert Fitch
* Date: 3/28/2023
* Edited: 4/2/2025
* Description: Input functions for Airgead Banking Investment Growth program
*/

#include "AirgeadBankingInput.h"
#include "AirgeadBankingDisplay.h"
#include "Investment.h"
#include "Sorting.h"
#include "User.h"
#include "InvestmentDB.h"
#include <string>
#include <iostream>
#include <iomanip>

double GetValidDouble(std::string outputMessage, int formatWidth) {
	double userInput;
	std::cout << std::endl << std::setw(formatWidth) << outputMessage;

	// Catch invalid input, and print an error
	while (!(std::cin >> userInput) || userInput < 0 || std::cin.get() != '\n') {
		std::cerr << "Invalid input (AirgeadBankingInput line 18)." << std::endl;
		std::cout << "Invalid input. Please try again" << std::endl;
		std::cin.clear();
		while (std::cin.get() != '\n');
		std::cout << std::endl << std::setw(formatWidth) << outputMessage;
	}

	return userInput;
}

int GetValidInt(std::string outputMessage, int formatWidth) {
	int userInt;
	std::cout << std::endl << std::setw(formatWidth) << outputMessage;

	while (!(std::cin >> userInt) || std::cin.get() != '\n') {
		std::cerr << "Invalid input (AirgeadBankingInput line 33)." << std::endl;
		std::cout << "Invalid input. Please try again." << std::endl;
		std::cin.clear();
		while (std::cin.get() != '\n'); // Loop through cin until it's fully cleared
		std::cout << std::endl << std::setw(formatWidth) << outputMessage;
	}
	return userInt;
}

void GetUserInvestment(Investment& currInvestment) {
	// Gets valid user input for investment
	currInvestment.SetInvestmentAmount(GetValidDouble("Initial Investment Amount: "));
	currInvestment.SetMonthlyDeposit(GetValidDouble("Monthly Deposit: ", 27));
	currInvestment.SetInterestRate(GetValidDouble("Annual Interest: ", 27));
	currInvestment.SetNumYears(GetValidInt("Number of years: ", 27));
	std::cout << std::endl;
}

bool GetAscDesc() {
	int userChoice;

	DisplayHeader(90, "Sort by Ascending or Descending?", '*', '*');
	std::cout << "1. Sort by Ascending" << std::endl;
	std::cout << "2. Sort by Descending" << std::endl;

	userChoice = GetValidInt("Enter Choice: ");
	while (userChoice < 0 || userChoice > 2) {
		std::cout << "Invalid input. Please enter a number between [1 - 2]." << std::endl;
		userChoice = GetValidInt("Enter Choice: ");
	}

	if (userChoice == 1) {
		return true;
	}
	else {
		return false;
	}
}