#ifndef LOGIN_H
#define LOGIN_H

#include "User.h"
#include <string>
#include <vector>

/*
* Creates a user and adds them to the text file
* 
* @returns the created user
* @param key Key used to encrypt user data
*/
User CreateUser(std::string key);

/*
* Takes a user, set's the user's data, and adds them to a text file
* 
* @param currUser User object to be updated by the function
* @param key Key used to encrypt user data
*/
void CreateUser(User& currUser, std::string key);

/*
* Checks to see if there are any special characters in a string
* 
* @param stringToCheck string variable to check
* @param isEmail is the string an email address?
* 
* @returns true if string doesn't contain special chars, false if special chars are found
*/
bool SanitizedString(std::string stringToCheck, bool isEmail = false);

/*
* Asks the user for string input and loops until a valid input is given
* 
* @param outputMessage message to be output to the user
* @param isEmail is the expected string an email address?
* 
* @returns a user input string with no special characters.
*/
std::string GetSanitizedString(std::string outputMessage, bool isEmail = false, int formatWidth = 0);

#endif