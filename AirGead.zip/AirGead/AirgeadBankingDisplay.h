/*
* Name: Robert Fitch
* Date: 3/28/2023
* Edited: 4/16/2025
* Description: Display functions for Airgead Banking Investment Growth program
*/

#ifndef AIRGEAD_BANKING_DISPLAY_H
#define AIRGEAD_BANKING_DISPLAY_H
#include <string>
#include <vector>
#include "Investment.h"

/*
* Creates a string of boarderLength length using boarderChar chars
* 
* @param boarderLength length of the boarder string
* @param boarderChar char that the boarder should me made out of
*/
std::string BoarderString(unsigned int boarderLength, char boarderChar);

/*
* Takes a string and centeres it in the middle of spaces
* 
* @param width int that reprsents total length to be used
* @param stringToCenter string that will be centered
* @param shift bool to shift the extra space to the right or left, default value = true
*/
std::string CenterString(unsigned int width, std::string stringToCenter, bool shift = true);

/*
* Displays a header with user defined string, and boarders
* 
* @param width int that represents the size of the header
* @param displayMessage string to be printed in the middle of the header
* @param topBottomBoarderChar char to be printed above and below the string
* @param sideBoarderChar char to be printed on the sides of the boarder
*/
void DisplayHeader(unsigned int width, std::string displayMessage, char topBottomBoarderChar = '-', char sideBoarderChar = '|');

/*
* Prints the header for the year-end report
*/
void DisplayYearEndHeader();

/*
* Prints the year-end values
* 
* @param year year to print
* @param yearEndBalance Balance to print
* @param yearEndInterest Interest to print
*/
void DisplayYearEndValues(int year, double yearEndBalance, double yearEndInterest);

/*
* Displays menu options to the user
* 
* @param User's first name to output
*/
void DisplayHomeMenu(std::string userName);

/*
* Displays the login menu
*/
void DisplayLoginMenu();

/*
* Displays the Sorting menu
*/
void DisplaySortingMenu();

/*
* Creates a string to show the data in a single investment
* 
* @param userInvestment The investment to display
* 
* @returns a string to display the investment data
*/
std::string DisplaySingleInvestment(Investment userInvestment);

/*
* Displays the users saved investments
* 
* @param investmentList a vector of Investment objects to be displayed
* @param limitToFive Displays five investments if true, all investments if false
*/
void DisplayLoadMenu(std::vector<Investment> investmentList, bool limitToFive = true);

/*
* Displays the Investment menu
*/
void DisplayInvestmentMenu(Investment &currInvestment);

#endif