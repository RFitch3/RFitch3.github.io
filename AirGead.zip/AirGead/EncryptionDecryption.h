/*
* Name: Robert Fitch
* Date: 3/26/2025
* Description: Encryption / Decryption function
*/
#ifndef ENCRYPTION_DECRYPTION_H
#define ENCRYPTION_DECRYPTION_H

#include <string>

/*
* Encrypts and decrypts a string using an xor encryption algorithm and a key
* 
* @param inputString The string to either encrypt or decrypt
* @param key The key used for encryption / decryption
* 
* @returns If passed an encrypted string, returns a decrypted string and visa versa
*/
std::string EncryptDecrypt(std::string inputString, std::string key);

#endif